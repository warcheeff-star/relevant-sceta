import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import crypto from 'node:crypto';
import {fileURLToPath} from 'node:url';
import {execFileSync} from 'node:child_process';

const MAGIC=Buffer.from('SCETA1\r\n');
export function unlock(data,password){
 if(!Buffer.isBuffer(data)||data.length<53||!data.subarray(0,8).equals(MAGIC))throw Error('Неверный формат пакета.');
 const key=crypto.scryptSync(password,data.subarray(8,24),32,{N:32768,r:8,p:1,maxmem:128*1024*1024});
 const decipher=crypto.createDecipheriv('aes-256-gcm',key,data.subarray(24,36));
 decipher.setAAD(MAGIC);decipher.setAuthTag(data.subarray(36,52));
 try{return Buffer.concat([decipher.update(data.subarray(52)),decipher.final()]);}
 catch{throw Error('Пароль не подходит или пакет повреждён. Установка не запущена.');}
 finally{key.fill(0);}
}

async function main(){
 const args=process.argv.slice(2);if(args.length!==2||args[0]!=='--out'||!args[1])throw Error('Использование: node unlock.mjs --out <новая папка>. Пароль передать через стандартный ввод.');
 if(Number(process.versions.node.split('.')[0])<22)throw Error('Нужен Node.js 22+ из среды приложения.');
 if(process.platform!=='win32')throw Error('Эта сборка установщика предназначена для Windows.');
 const password=fs.readFileSync(0,'utf8').replace(/\r?\n$/,'');if(!password)throw Error('Не указан пароль.');
 const base=path.dirname(fileURLToPath(import.meta.url)),manifest=JSON.parse(fs.readFileSync(path.join(base,'release.json'),'utf8'));
 const data=fs.readFileSync(path.join(base,manifest.file));
 if(crypto.createHash('sha256').update(data).digest('hex')!==manifest.sha256)throw Error('Контрольная сумма пакета не совпала.');
 const plain=unlock(data,password);
 const destination=path.resolve(args[1]);if(fs.existsSync(destination))throw Error('Папка назначения уже существует. Выберите новую, не перезаписывайте прежнюю установку.');
 const temporary=fs.mkdtempSync(path.join(os.tmpdir(),'relevant-sceta-'));
 const zip=path.join(temporary,'package.zip');fs.writeFileSync(zip,plain,{mode:0o600});plain.fill(0);
 const ps=String.raw`$ErrorActionPreference='Stop'
Add-Type -AssemblyName System.IO.Compression.FileSystem
$zipPath=$env:SCETA_ZIP
$destination=[IO.Path]::GetFullPath($env:SCETA_DEST)
$prefix=$destination.TrimEnd([IO.Path]::DirectorySeparatorChar)+[IO.Path]::DirectorySeparatorChar
$archive=[IO.Compression.ZipFile]::OpenRead($zipPath)
try { foreach($entry in $archive.Entries){
 $name=$entry.FullName.Replace('/',[IO.Path]::DirectorySeparatorChar)
 if([IO.Path]::IsPathRooted($name) -or $name.Contains(':')){throw 'Недопустимый путь в архиве'}
 $target=[IO.Path]::GetFullPath([IO.Path]::Combine($destination,$name))
 if(-not $target.StartsWith($prefix,[StringComparison]::OrdinalIgnoreCase)){throw 'Путь выходит за папку распаковки'}
} } finally { $archive.Dispose() }
[IO.Compression.ZipFile]::ExtractToDirectory($zipPath,$destination)
`;
 execFileSync('powershell.exe',['-NoProfile','-NonInteractive','-Command',ps],{env:{...process.env,SCETA_ZIP:zip,SCETA_DEST:destination},windowsHide:true,stdio:['ignore','pipe','pipe']});
 // Delete only the single temporary ZIP we just created; leave extracted files for review.
 fs.unlinkSync(zip);
 console.log(JSON.stringify({unlocked:true,version:manifest.version,path:destination,next:'Прочитайте START-HERE.md и проверьте файлы установщика перед запуском. Плагин пока не установлен.'},null,2));
}
if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url))main().catch(e=>{console.error(JSON.stringify({ok:false,message:e.message}));process.exitCode=1;});
